<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>داشبورد</title>
    <script src="<?php echo e(asset('js/app.js?v=').$company_information->app_version); ?>" defer></script>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <link href="<?php echo e(asset('css/app.css?v=').$company_information->app_version); ?>" rel="stylesheet">
    <script>
        window.Laravel = <?php echo json_encode([
        'user' => auth()->check() ? auth()->user()->id : null,
    ]); ?>;
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</head>
<body class="dashboard-container">
<div id="app">
    <loading v-show="show_loading" v-cloak></loading>
    <header class="rtl header position-fixed w-100">
        <?php if(auth()->user()->is_admin): ?>
            <ul class="nav nav-tabs bg-menu pr-2 pl-2" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link menu-header-item" id="menu-tab" data-toggle="tab" href="#menu" role="tab" aria-controls="menu" aria-selected="true">
                        <span class="menu-header-text iransans">منو</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link menu-header-item" id="contract-tab" data-toggle="tab" href="#contract" role="tab" aria-controls="contract" aria-selected="true">
                        <span class="menu-header-text iransans">قرارداد</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link user-header-item" id="user-tab" data-toggle="tab" href="#user" role="tab" aria-controls="user" aria-selected="true">
                        <span class="menu-header-text iransans">کاربران</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link user-header-item" id="performance-tab" data-toggle="tab" href="#performance" role="tab" aria-controls="performance" aria-selected="true">
                        <span class="menu-header-text iransans">اتوماسیون</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link user-header-item" id="settings-tab" data-toggle="tab" href="#settings" role="tab" aria-controls="settings" aria-selected="true">
                        <span class="menu-header-text iransans">تنظیمات</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="account-tab" data-toggle="tab" href="#account" role="tab" aria-controls="account" aria-selected="true">
                        <span class="menu-header-text iransans">حساب کاربری</span>
                    </a>
                </li>
            </ul>
            <div class="tab-content position-absolute w-100" id="menu-contents" style="box-shadow: 0 5px 5px -1px #e7e7e7">
                <div class="tab-pane fade pb-2 pt-2" id="menu" role="tabpanel" aria-labelledby="menu-tab">
                    <ul class="ribbon-container">
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("MenuHeaders.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/menu.png?v=oo")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">سرفصل منو</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("MenuItems.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/menu-item.png?v=oko")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">عناوین منو</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("MenuActions.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/menu-action.png?v=olpo")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">عملیات منو</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="tab-pane fade pb-2 pt-2" id="contract" role="tabpanel" aria-labelledby="contract-tab">
                    <ul class="ribbon-container">
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("AdminContractHeader.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/menu.png?v=oo")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">قرارداد</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("AdminContractSubset.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/menu-item.png?v=oko")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">زیرمجموعه قرارداد</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="tab-pane pb-2 pt-2 fade" id="user" role="tabpanel" aria-labelledby="user-tab">
                    <ul class="ribbon-container">
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("Users.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/users.png?n=op")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">کاربران</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("Roles.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/role.png?n=op")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">عنوان شغلی</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="tab-pane fade pb-2 pt-2" id="performance" role="tabpanel" aria-labelledby="performance-tab">
                    <ul class="ribbon-container">
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("AutomationFlow.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/menu.png?v=oo")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">جریان گردش اتوماسیون</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="tab-pane pb-2 pt-2 fade" id="settings" role="tabpanel" aria-labelledby="settings-tab">
                    <ul class="ribbon-container">
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("DefaultTableAttributes.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/company.png?n=op")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">عناوین پیش فرض</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("TableAttributes.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/company.png?n=op")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">عناوین ورودی</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("InvoiceCoverTitles.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/company.png?n=op")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">عناوین روکش وضعیت</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("Advantages.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/company.png?n=op")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">عناوین تغییرات مزایا</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("CompanyInformation.index")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-around">
                                <img class="ribbon-item-icon" src="<?php echo e(asset("/images/menu/company.png?n=op")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">اطلاعات سازمان</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="tab-pane fade pb-2 pt-2" id="account" role="tabpanel" aria-labelledby="account-tab">
                    <ul class="ribbon-container">
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("account.information")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-between">
                                <img src="<?php echo e(asset("/storage/menu_item_icons/")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">حساب کاربری</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("account.verification")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-between">
                                <img src="<?php echo e(asset("/storage/menu_item_icons/")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">تاییدیه اطلاعات</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <a role="button" href="<?php echo e(route("user.password.reset")); ?>" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-between">
                                <img src="<?php echo e(asset("/storage/menu_item_icons/")); ?>" alt="menu">
                                <span class="iranyekan ribbon-item-text">تغییر گذرواژه</span>
                            </a>
                        </li>
                        <li class="position-relative ribbon-li">
                            <form id="logout_form" class="p-0 m-0 w-20 d-inline" action="<?php echo e(route("logout")); ?>" method="post" v-on:submit="logout">
                                <?php echo csrf_field(); ?>
                                <div class="form-row p-0 m-0">
                                    <div class="form-group col-12 p-0 m-0">
                                        <button type="submit" form="logout_form" class="ribbon-item btn btn-light d-flex flex-column align-items-center justify-content-between">
                                            <img src="<?php echo e(asset("/storage/menu_item_icons/")); ?>" alt="menu">
                                            <span class="iranyekan ribbon-item-text">خروج</span>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </header>
    <div class="main rtl container-fluid pr-3 pl-3" v-on:click="hide_ribbon">
        <?php if($errors->any()): ?>
            <div class="w-100 mt-2 error-box">
                <div class="alert alert-danger iransans mb-0 h-100 border border-danger pt-3 pb-3" role="alert">
                    <h6 class="font-weight-bold">
                        <i class="fa fa-exclamation-circle fa-1-4x red-color"></i>
                        در هنگام اجرای عملیات، خطا(های) زیر رخ داده است:
                    </h6>
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="iransans"><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
        <?php if(session()->has("result")): ?>
            <div class="information-box w-100 mt-2">
                <div class="alert alert-<?php echo e(session("result")); ?> iransans mb-0 h-100 border border-<?php echo e(session("result")); ?> pt-3 pb-3" role="alert">
                    <h6 class="pt-2 font-weight-bold">
                        <?php switch(session("result")):
                            case ("success"): ?>
                                <i class="fa fa-check-circle fa-1-4x green-color"></i>
                                <?php break; ?>
                            <?php case ("warning"): ?>
                                <i class="fa fa-exclamation-triangle fa-1-4x red-color"></i>
                                <?php break; ?>
                        <?php endswitch; ?>
                        <?php switch(session("message")):
                            case ("unknown"): ?>
                                <span>نتیجه عملیات نامشخص می باشد</span>
                                <?php break; ?>
                            <?php case ("saved"): ?>
                                <span>عملیات ذخیره سازی با موفقیت انجام شد</span>
                                <?php break; ?>
                            <?php case ("incomplete_import"): ?>
                                <span>عملیات ذخیره سازی با موفقیت انجام شد اما ثبت اطلاعات فایل اکسل به طور کامل انجام نشد</span>
                                <a href="#" role="button" data-toggle="modal" data-target="#import_errors">
                                    مشاهده بیشتر
                                </a>
                                <?php break; ?>
                            <?php case ("updated"): ?>
                                <span>عملیات ویرایش با موفقیت انجام شد</span>
                                <?php break; ?>
                            <?php case ("deleted"): ?>
                                <span>عملیات حذف با موفقیت انجام شد</span>
                                <?php break; ?>
                            <?php case ("relation_exists"): ?>
                                <span>به دلیل وجود رابطه با اطلاعات دیگر،امکان حذف آن وجود ندارد</span>
                                <?php break; ?>
                            <?php case ("inactive"): ?>
                                <span>عملیات غیرفعال سازی با موفقیت انجام شد</span>
                                <?php break; ?>
                            <?php case ("active"): ?>
                                <span>عملیات فعال سازی با موفقیت انجام شد</span>
                                <?php break; ?>
                            <?php case ("confirmed"): ?>
                                <span>عملیات تایید نهایی با موفقیت انجام شد</span>
                                <?php break; ?>
                            <?php case ("sent"): ?>
                                <span>عملیات تایید و ارسال با موفقیت انجام شد</span>
                                <?php break; ?>
                            <?php case ("referred"): ?>
                                <span>عملیات عدم تایید و ارجاع با موفقیت انجام شد</span>
                                <?php break; ?>
                        <?php endswitch; ?>
                    </h6>
                </div>
            </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <footer class="d-flex bottom w-100 p-1 bg-menu">
        <span class="text-center iranyekan font-weight-bold font-size-sm pt-2 pr-2 pl-2 pb-1 ml-2 d-flex align-items-center justify-content-center" style="border: 1px inset #d5d5d5">
            <i class="fa fa-buildings fa-1-2x ml-1"></i>
            <?php echo e($company_information->name); ?>

        </span>
        <span class="text-center iranyekan font-weight-bold font-size-sm  pt-2 pr-2 pl-2 pb-1 ml-2 d-flex align-items-center justify-content-center" style="border: 1px inset #d5d5d5">
            <i class="fa fa-user fa-1-2x ml-1"></i>
            <?php echo e($auth_user->name); ?>

        </span>
        <span class="text-center iranyekan font-weight-bold font-size-sm pt-2 pr-2 pl-2 pb-1 ml-2 d-flex align-items-center justify-content-center" style="border: 1px inset #d5d5d5">
            <i class="fa fa-user-cog fa-1-2x ml-1"></i>
            <?php echo e("مدیر سیستم"); ?>

        </span>
        <span class="text-center iranyekan font-weight-bold font-size-sm pt-2 pr-2 pl-2 pb-1 ml-2 d-flex align-items-center justify-content-center" style="border: 1px inset #d5d5d5">
            <i class="fa fa-shield fa-1-2x ml-1"></i>
            <?php echo e("پروفایل : "); ?>

            <?php if($auth_user->email_verified_at != null && $auth_user->mobile_verified_at != null): ?>
                <span class="text-center iranyekan font-weight-bold font-size-sm green-color">تایید شده</span>
            <?php elseif($auth_user->email_verified_at != null && $auth_user->mobile_verified_at == null): ?>
                <span class="text-center iranyekan font-weight-bold font-size-sm green-color">ایمیل</span>
            <?php elseif($auth_user->email_verified_at == null && $auth_user->mobile_verified_at != null): ?>
                <span class="text-center iranyekan font-weight-bold font-size-sm green-color">تلفن همراه</span>
            <?php else: ?>
                <span class="text-center iranyekan font-weight-bold font-size-sm red-color">تایید نشده</span>
            <?php endif; ?>
        </span>
        <span class="text-center iranyekan font-weight-bold font-size-sm pt-2 pr-2 pl-2 pb-1 ml-2 d-flex align-items-center justify-content-center" style="border: 1px inset #d5d5d5">
            <i class="fa fa-box-circle-check fa-1-2x ml-1"></i>
            <?php echo e("نسخه ".$company_information->app_version); ?>

        </span>
    </footer>
    <?php echo $__env->yieldContent('modals'); ?>
</div>
</body>
</html>
<?php /**PATH F:\WebProjects\hss_emp\resources\views/layouts/admin_dashboard.blade.php ENDPATH**/ ?>