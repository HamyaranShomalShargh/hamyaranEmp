<table style="direction: rtl">
    <thead>
    <tr>
        <th style="color: #ffffff;background-color: #343A40">
            نام
            <strong style="color: red">*</strong>
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            نام خانوادگی
            <strong style="color: red">*</strong>
        </th>
        <th style="color: #ffffff;background-color: #343A40">جنسیت</th>
        <th style="color: #ffffff;background-color: #343A40">
            کد ملی
            <strong style="color: red">*</strong>
        </th>
        <th style="color: #ffffff;background-color: #343A40">شماره شناسنامه</th>
        <th style="color: #ffffff;background-color: #343A40">تاریخ تولد</th>
        <th style="color: #ffffff;background-color: #343A40">محل تولد</th>
        <th style="color: #ffffff;background-color: #343A40">تحصیلات</th>
        <th style="color: #ffffff;background-color: #343A40">خدمت سربازی</th>
        <th style="color: #ffffff;background-color: #343A40">وضعیت تاهل</th>
        <th style="color: #ffffff;background-color: #343A40">تعداد فرزند</th>
        <th style="color: #ffffff;background-color: #343A40">شماره بیمه</th>
        <th style="color: #ffffff;background-color: #343A40">سابقه بیمه</th>
        <th style="color: #ffffff;background-color: #343A40">حقوق پایه</th>
        <th style="color: #ffffff;background-color: #343A40">دستمزد روزانه</th>
        <th style="color: #ffffff;background-color: #343A40">بن ماهیانه</th>
        <th style="color: #ffffff;background-color: #343A40">کمک هزینه مسکن</th>
        <th style="color: #ffffff;background-color: #343A40">حق اولاد</th>
        <th style="color: #ffffff;background-color: #343A40">گروه شغلی</th>
        <th style="color: #ffffff;background-color: #343A40">نام بانک</th>
        <th style="color: #ffffff;background-color: #343A40">شماره حساب</th>
        <th style="color: #ffffff;background-color: #343A40">شماره کارت</th>
        <th style="color: #ffffff;background-color: #343A40">شماره شبا</th>
        <th style="color: #ffffff;background-color: #343A40">تلفن</th>
        <th style="color: #ffffff;background-color: #343A40">موبایل</th>
        <th style="color: #ffffff;background-color: #343A40">آدرس</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
