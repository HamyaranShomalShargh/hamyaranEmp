<table style="direction: rtl">
    <thead>
    <tr>
        <th style="color: #ffffff;background-color: #343A40">
            عناوین(به ترتیب ثبت در سیستم بارگذاری خواهند شد)
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            نوع ورودی(text,number)
        </th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
