<?php $__env->startPush('scripts'); ?>
    <script>
        let new_performance_data = <?php echo json_encode($new_performance_notifications, 15, 512) ?>;
        let new_invoice_data = <?php echo json_encode($new_invoice_notifications, 15, 512) ?>;
        let new_advantage_data = <?php echo json_encode($new_advantage_notifications, 15, 512) ?>;
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page w-100 pt-3">
        <?php if(auth()->user()->email == null): ?>
            <div class="alert alert-danger iransans mb-0 h-100 border border-danger pt-3 pb-3 mb-3" role="alert">
                <h6 class="pt-2 font-weight-bold">
                    <i class="fa fa-envelope mr-1 fa-1-4x black-color" style="color: #980000"></i>
                    <a href="<?php echo e(route("account.information")); ?>" role="button" style="color: #980000">
                        آدرس پست الکترونیکی شما در حساب کاربری ثبت نشده است. لطفا نسبت به ثبت و تایید آن اقدام فرمایید.
                    </a>
                </h6>
            </div>
        <?php endif; ?>
        <?php if(auth()->user()->mobile == null): ?>
            <div class="alert alert-danger iransans mb-0 h-100 border border-danger pt-3 pb-3 mb-3" role="alert">
                <h6 class="pt-2 font-weight-bold">
                    <i class="fa fa-mobile mr-1 fa-1-4x black-color" style="color: #980000"></i>
                    <a href="<?php echo e(route("account.information")); ?>" role="button" style="color: #980000">
                        شماره تلفن همراه شما در حساب کاربری ثبت نشده است. لطفا نسبت به ثبت و تایید آن اقدام فرمایید.
                    </a>
                </h6>
            </div>
        <?php endif; ?>
        <?php if(auth()->user()->email != null && auth()->user()->email_verified_at == null): ?>
            <div class="alert alert-danger iransans mb-0 h-100 border border-danger pt-3 pb-3 mb-3" role="alert">
                <h6 class="pt-2 font-weight-bold">
                    <i class="fa fa-envelope-open mr-1 fa-1-4x black-color" style="color: #980000"></i>
                    <a href="<?php echo e(route("account.verification")); ?>" role="button" style="color: #980000">
                        آدرس پست الکترونیکی شما در حساب کاربری تایید نشده است. لطفا نسبت به تایید آن اقدام فرمایید.
                    </a>
                </h6>
            </div>
        <?php endif; ?>
        <?php if(auth()->user()->mobile != null && auth()->user()->mobile_verified_at == null): ?>
            <div class="alert alert-danger iransans mb-0 h-100 border border-danger pt-3 pb-3 mb-3" role="alert">
                <h6 class="pt-2 font-weight-bold">
                    <i class="fa fa-mobile-signal mr-1 fa-1-4x black-color" style="color: #980000"></i>
                    <a href="<?php echo e(route("account.verification")); ?>" role="button" style="color: #980000">
                        شماره تلفن همراه شما در حساب کاربری تایید نشده است. لطفا نسبت به تایید آن اقدام فرمایید.
                    </a>
                </h6>
            </div>
        <?php endif; ?>
        <div class="mt-2" v-cloak>
            <div class="alert alert-info iransans mb-0 h-100 border border-info pt-3 pb-3 mb-3" role="alert" v-for="notification in new_performance_notifications">
                <h6 class="pt-2 font-weight-bold">
                    <i class="fa fa-mailbox mr-2 fa-1-4x black-color" style="color: #005cbf"></i>
                    <a :href="notification.action" role="button">
                        {{ notification.message }}
                    </a>
                </h6>
            </div>
        </div>
        <div class="mt-2" v-cloak>
            <div class="alert alert-success iransans mb-0 h-100 border border-success pt-3 pb-3 mb-3" role="alert" v-for="notification in new_invoice_notifications">
                <h6 class="pt-2 font-weight-bold">
                    <i class="fa fa-mailbox mr-2 fa-1-4x" style="color: #1a5d2b"></i>
                    <a :href="notification.action" role="button" style="color: #1a5d2b">
                        {{ notification.message }}
                    </a>
                </h6>
            </div>
        </div>
        <div class="mt-2" v-cloak>
            <div class="alert alert-dark iransans mb-0 h-100 border border-dark pt-3 pb-3 mb-3" role="alert" v-for="notification in new_advantage_notifications">
                <h6 class="pt-2 font-weight-bold">
                    <i class="fa fa-mailbox mr-2 fa-1-4x" style="color: #000000"></i>
                    <a :href="notification.action" role="button" style="color: #000000">
                        {{ notification.message }}
                    </a>
                </h6>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.staff_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebProjects\hss_emp\resources\views/staff/idle.blade.php ENDPATH**/ ?>