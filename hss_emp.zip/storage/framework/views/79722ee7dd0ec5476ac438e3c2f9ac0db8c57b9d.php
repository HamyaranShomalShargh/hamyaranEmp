<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>ورود به سیستم</title>
    <script src="<?php echo e(asset('js/app.js?v='.time())); ?>" defer></script>
    <link href="<?php echo e(asset('css/app.css?v='.time())); ?>" rel="stylesheet">
    <script>
        window.Laravel = <?php echo json_encode([
        'user' => auth()->check() ? auth()->user()->id : null,
    ]); ?>;
    </script>
</head>
<body style="background: #0d1117">
<div id="app">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 text-center pt-5 pb-5">
                <img src="<?php echo e(asset("/images/bw-logo.png?v=jj")); ?>" alt="logo"/>
                <h5 class="mid-white-color iransans text-center mt-4">مدیریت کارکرد ماهانه</h5>
            </div>
            <div class="col-12 text-center">
                <h5 class="text-muted pb-2 iranyekan">ورود به سیستم</h5>
            </div>
            <div class="login-box pt-3 pb-4 pr-3 pl-3 rtl">
                <form id="login_form" method="POST" action="<?php echo e(route('login')); ?>" v-on:submit="login">
                    <?php echo csrf_field(); ?>
                    <label class="mid-white-color iranyekan form-lbl">
                        <i class="fa fa-user"></i>
                        نام کاربری
                    </label>
                    <input type="text" autofocus tabindex="1" class="form-control login-input-text <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username">
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback iranyekan text-center" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label class="mid-white-color iranyekan form-lbl mt-3">
                        <i class="fa fa-key"></i>
                        کلمه عبور
                        <a tabindex="-1" href="<?php echo e(route("password.reset")); ?>">(فراموشی کلمه عبور)</a>
                    </label>
                    <input type="password" tabindex="2" class="form-control login-input-text <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback iranyekan text-center" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label class="mid-white-color iranyekan form-lbl mt-3">
                        <i class="fa fa-shield-blank"></i>
                        کد امنیتی
                        <a tabindex="-1" href="#" v-on:click="recaptcha"><i class="fa fa-refresh fa-1-2x"></i></a>
                    </label>
                    <span class="captcha-image d-block mb-2 text-center"><?php echo Captcha::img(); ?></span>
                    <input type="text" tabindex="3" class="form-control login-input-text captcha-input iranyekan font-size-xl number_masked <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-mask="000000" name="captcha">
                    <div class="login-errors">
                        <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block iranyekan font-size-lg text-center p-0 m-0" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['login_failed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback iranyekan d-block font-size-lg text-center p-0 m-0" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button tabindex="4" type="submit" class="btn btn-outline-success form-control iranyekan login-button">
                        <i id="login-button-icon" class="fa fa-sign-in fa-1-2x mr-2"></i>
                        <span id="login-button-text" class="font-size-lg">ورود به سیستم</span>
                    </button>
                </form>
            </div>
        </div>
        <div class="row justify-content-center mt-2 iranyekan text-muted font-size-sm d-flex flex-column justify-content-center align-items-center">
        <span>
            <i class="fa fa-copyright"></i>
            کلیه حقوق متعلق به شرکت همیاران شمال شرق می باشد.
        </span>
            <span>نسخه 2.0.1</span>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH F:\WebProjects\hss_emp\resources\views/auth/login.blade.php ENDPATH**/ ?>